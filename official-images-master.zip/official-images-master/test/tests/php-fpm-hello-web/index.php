<?php echo isset($_REQUEST['hello']) ? $_REQUEST['hello'] : 'Hello!';
